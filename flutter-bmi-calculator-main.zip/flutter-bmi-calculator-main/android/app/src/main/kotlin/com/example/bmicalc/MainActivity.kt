package com.example.bmicalc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
