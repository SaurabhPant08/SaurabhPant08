//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import soundpool_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  SwiftSoundpoolPlugin.register(with: registry.registrar(forPlugin: "SwiftSoundpoolPlugin"))
}
