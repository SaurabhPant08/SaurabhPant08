package com.aasharef.weather_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
